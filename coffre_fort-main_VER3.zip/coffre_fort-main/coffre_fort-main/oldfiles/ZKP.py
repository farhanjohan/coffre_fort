import secrets
from derivation import sponge_hash

class ZKPAuth ():
    def __init__(self, derived_key, p=23, g=5):
        if p <= 2 or not self._is_prime(p):
            raise ValueError("'p' doit être un nombre premier supérieur à 2.")
        if not 1 < g < p:
            raise ValueError("'g' doit être un générateur valide dans le groupe cyclique défini par p.")

        self.p = p  # Nombre premier
        self.g = g  # Générateur
        self.cle_privee = derived_key  # Clé privée
        self.cle_publique = pow(self.g, self.cle_privee, self.p)  # Clé publique

    def generer_preuve(self):
        # Étape 1 : Générer un engagement
        self.r = secrets.randbelow(self.p - 1)
        self.M = pow(self.g, self.r, self.p)
        return self.M

    def verifier_preuve(self, challenge, preuve):
        # Vérification de la preuve
        gauche = (pow(self.g, preuve, self.p) * pow(self.cle_publique, challenge, self.p)) % self.p
        return gauche == self.M

    def repondre_challenge(self, challenge):
        # Calculer la réponse au challenge
        if not (0 <= challenge < self.p):
            raise ValueError("Le challenge doit être un entier dans l'ensemble [0, p-1].")
        preuve = (self.r - challenge * self.cle_privee) % (self.p - 1)
        return preuve

    @staticmethod
    def _is_prime(n):
        # Méthode pour vérifier si un nombre est premier
        if n <= 1:
            return False
        for i in range(2, int(n**0.5) + 1):
            if n % i == 0:
                return False
        return True