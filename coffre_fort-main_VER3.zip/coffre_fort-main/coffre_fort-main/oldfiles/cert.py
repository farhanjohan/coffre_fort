from cryptography.hazmat.primitives.asymmetric import rsa, padding
from cryptography.hazmat.primitives import serialization, hashes
from cryptography.hazmat.primitives.serialization import load_pem_public_key
from cryptography.x509 import load_pem_x509_certificate
from cryptography.x509 import NameOID
from cryptography import x509
import datetime

def generate_certificate():
    # Generate private key
    private_key = rsa.generate_private_key(
        public_exponent=65537,
        key_size=2048,
    )
    public_key = private_key.public_key()

    # Build the certificate
    subject = issuer = x509.Name([
        x509.NameAttribute(NameOID.COUNTRY_NAME, "FR"),
        x509.NameAttribute(NameOID.ORGANIZATION_NAME, "Coffre-Fort"),
        x509.NameAttribute(NameOID.COMMON_NAME, "coffre-fort.local"),
    ])
    certificate = x509.CertificateBuilder()\
        .subject_name(subject)\
        .issuer_name(issuer)\
        .public_key(public_key)\
        .serial_number(x509.random_serial_number())\
        .not_valid_before(datetime.datetime.utcnow())\
        .not_valid_after(datetime.datetime.utcnow() + datetime.timedelta(days=365))\
        .sign(private_key, hashes.SHA256())

    # Save the certificate and private key
    with open("server_cert.pem", "wb") as cert_file:
        cert_file.write(certificate.public_bytes(serialization.Encoding.PEM))
    with open("server_key.pem", "wb") as key_file:
        key_file.write(private_key.private_bytes(
            serialization.Encoding.PEM,
            serialization.PrivateFormat.TraditionalOpenSSL,
            serialization.NoEncryption()
        ))

    print("Certificate and key generated.")

def get_ca_public_key(ca_cert_path):
    # Load the CA certificate
    with open(ca_cert_path, "rb") as cert_file:
        ca_cert = load_pem_x509_certificate(cert_file.read())
    # Extract and return the CA's public key
    return ca_cert.public_key()
    
def verify_certificate(certificate_path, ca_public_key):
    # Load the server certificate
    with open(certificate_path, "rb") as cert_file:
        certificate = load_pem_x509_certificate(cert_file.read())

    # Verify the certificate's signature
    try:
        ca_public_key.verify(
            certificate.signature,
            certificate.tbs_certificate_bytes,
            padding.PKCS1v15(),
            certificate.signature_hash_algorithm,
        )
        print("Certificate verified successfully.")
        return True
    except Exception as e:
        print(f"Certificate verification failed: {e}")
        return False

generate_certificate()