def zkp_authenticate(username, password):
    import secrets
    from derivation import sponge_hash
    from ZKP import ZKPAuth

    # Génération de la clé privée à partir du mot de passe
    derived_key = sponge_hash(password)

    # Chargement des paramètres publics (par exemple depuis une base de données)
    # Simulation ici pour démonstration
    p = 23  # Exemple de nombre premier
    g = 5   # Exemple de générateur
    zkp = ZKPAuth(derived_key, p, g)

    # Début du protocole ZKP
    print(f"Clé publique : {zkp.cle_publique}")

    # Étape 1 : Génération de l'engagement
    M = zkp.generer_preuve()
    print(f"Engagement (M) envoyé : {M}")

    # Étape 2 : Génération d'un challenge
    challenge = secrets.randbelow(zkp.p - 1)
    print(f"Challenge envoyé : {challenge}")

    # Étape 3 : Réponse au challenge
    preuve = zkp.repondre_challenge(challenge)
    print(f"Preuve envoyée : {preuve}")

    # Vérification de la preuve
    verification = zkp.verifier_preuve(challenge, preuve)
    if verification:
        print("Authentification réussie.")
        return True
    else:
        print("Authentification échouée.")
        return False
