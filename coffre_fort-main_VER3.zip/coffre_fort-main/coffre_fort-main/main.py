import os
import hashlib
import secrets
import json
import user_management
import derivation
from auth import *
from credentials import *

def main():

    username = input("Entrez un nom d'utilisateur : ")
    if os.path.exists(username):
        print(f"L'utilisateur {username} existe.")
        password = input("Entrez le mot de passe pour authentification : ")

        if authenticate_user(username, password):
            print("Access granted to the coffre-fort.")
        else:
            print("Access denied.")

    else :
        # 1) Enrollement
        print(f"L'utilisateur {username} n'existe pas. Creation d'un nouvel compte")
        password = input("Entrez le mot de passe : ")
        user_management.create_account(username, password)

        # 2) Dérivation de la clé (KDF)
        derived_key = derivation.derive_key(password)
        return



if __name__ == "__main__":
    main()


