from auth import authenticate_user

# Test persistent mode
print("Testing persistent certificate mode:")
if authenticate_user("kola", "kola123"):
    print("Access granted.")
else:
    print("Access denied.")


